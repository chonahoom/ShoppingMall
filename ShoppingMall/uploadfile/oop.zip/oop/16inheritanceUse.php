<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
      require_once "15inheritanceSubEx.php";
      $obj = new AddNumberSub();
      $obj->add(30);
      $obj->recorder();
      $obj->add(100);
      print 'num='.$obj->getNum().'<br>';

     ?>
  </body>
</html>
