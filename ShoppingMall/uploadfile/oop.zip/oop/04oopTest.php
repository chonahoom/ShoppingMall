<<<Referance(참조)>>>
  : new로 인스턴스를 생성할 때,
    인스탄스의 참조값(주소값,pointer)을 변수에 저장
1)변수의 참조
$a = 10;
$b = &$a // & : 참조연산자-주소연산자
$c = $a;
$b = 50;

인수
  가인수(카리히키스우,카비키스우)
    parameter, formal parameter(argument)
  실인수(지츠히키스우)
    argument, actual argument(parameter)
  함수:칸스우,데츠츠기 : procedure(프로지-쟈-)
  -함수 호출(가인수에 실인수를 전달하는 방식)
    1)call by value(값전달 호출,네와타시)
    2)call by reference(참조전달 호출,산쇼우와타시)

2)배열(객체)의 참조
  call by value
  call by reference

3)인스탄스의 참조
$ob = new TestCls();
$ob1 = $ob;
$ob2 = &$ob; //ob를 거쳐서 TestCls()로

※참조 카운터:하나의 인스탄스를 참조하는 변수의 갯수
  0이되면 인스탄스 파기됨

4)인스탄스의 코피(copy,복사) : clone $인스탄스;

5)인스탄스의 비교
== : 동일한 클래스의 인스탄스이고 동일한 프로파티값을 가지고 있
     으면 참
=== : 동일한 클래스의 동일한 인스탄스이어야 참

6)순환참조 : 인스턴스가 자신의 인스탄스를 참조
$a = new Test();
$a->self=$a; //참조카운터2
unset($a); //참조는 없는대 참조카운터 1
