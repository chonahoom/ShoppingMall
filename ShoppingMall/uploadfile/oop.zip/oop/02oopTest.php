<<<상속:inheritance>>>
계승(찾아보기 일본어)
1.클래스의 계승
 기존 클래스의 프로파티,메소드 등 멤버들을 그대로 상속받아
 새로운 클래스를 정의하는 것 , 다중상속의 금지
 기존 : 상속받는 클래스
 부모 : 자식클래스
 상위 : 하위클래스
 기본 : 파생 클래스
 스-파 : 사-부 클래스 (Super : Sub 클래스)

 class 사부클래스 extends 스-파-클래스{
   //사부클래스의 독자적인 멤버를 추가함.
 }

 2.오-바-라이도 : 메소드의 오-바-라이도
                 스-파-클래스의 멤버 메소드를 사부클래스에서 재정의
조건)
1>스-파-클래스의 메서드 명과 같아야
2>스-파-클래스의 메서드 파라메-타-구성이 같아야 한다.
3>아쿠세스수식자의 허용 범위를 같거나 확대하는 방향으로

public -> public
protected -> protected,public

*오-바-라이도한 스-파-클래스의 메소드를 호출하려면
parent::메소드명(인수리트스);

*php에서 사부클래스에서 인스탄스화할 떄 특별히 지정하지 않으면
 스-파-클래스의 생성자가 호출되지 않음
특별히 지정하는 방법: parent::__construct(인수리스트);

*오-바-라이도를 금지시키기
final
public final function 메소드명(인수리스트){}

$계승금지:final
final class 클래스명{}

3.포리모-휘즈무 : polymorphism 다형성
동일한 이름의 메소드로 상황에 따라 서로 다른 처리를 가능하게 하는 것
장점 : 같은 목적의 기능을 위해서 다른 메소드명을 기억할 필요가 없다.

*객체지향의 3대요소: encapsulation(information hiding)
                    inheritance
                    polymorphism

*포리모-휘즈무를 실현하기 위해 계승 => 오-바-라이도로 실현

why?사부클래스에서 오-바-라이도한다는 보장이 없다.
해결-->추상클래스와 인터페이스

4.Abstract 클래스
abstract 메소드:구현부분이 없다.
                abstract 수식자 적는다.
                상속받는 사부 클래스에서는 반드시 구현해야한다.
                (오-바-라이도해서 구현함)
abstract 클래스: abstract 메소드를 가지고 있는 클래스
abstract class 클래스명{
  abstract 아쿠세스수식자 function 메소드명(인수리스트);
}

구현:implementation : 실장
    추상메소드를 사부클래스에서 오-바-라이도하여 구체적으로 코딩하는 것
사용 가능 아쿠세스수식자:protected,public

3.인터-훼-스 : 추상메소드만 가진 특수한 클래스
메소드 내용은 몰라도 사용법만 알게 하기 위해서
-추상메소드만 정의
-abstract를 붙이지 않음(자동으로 추상메소드됨)
-사용가능 아쿠세스수식자:public만,생략가능

1)인터-훼-스의 선언
interface 인타-훼-스명{
  const 상수명=값;
  public function 메소드명(파라메-타-리스트)
}
2)인타-훼-이스의 실장: 구현 implements

class 클래스명 implements 인타-훼-스명1,....,인타-훼-스명n{
  //인타-훼-스의 메소드를 실장함
}
※인타-훼-스의를 실장(짓소우)한 클래스에서 인타-훼-스 상수를 참조
: 인타-훼-스명::상수명,self::상수명

※클래스나 인타-훼-스 정보를 알아내는 함수
get_class($인스탄스참조변수);
get_class_methods('클래스명');
get_class_methods(new 클래스명()); ==> 인스턴스 참조변수도 가능
get_object_vars($인스턴스참조변수);
get_parent_class($인스턴스 참조변수)
get_parent_class('클래스명');

※객체의 type check : instanceof
