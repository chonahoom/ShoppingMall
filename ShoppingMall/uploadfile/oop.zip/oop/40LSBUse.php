<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
    require_once "39LSBex1.php";
    require_once "39LSBex2.php";
    // $obj = new LSB_A();
    // $obj->test();
    // $obj2 = new LSB_B();
    // $obj2->test();
    $obj = new LSB_A();
    $b = $obj;
    $b->test();
    var_dump($b);
    echo "<br>";
    $a = &$obj;
    var_dump($a);
    //$a->test();
     ?>
  </body>
</html>
