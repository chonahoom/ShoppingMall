<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
    require_once "09staticProperty.php";
    echo "프로퍼티pi = ".StaticClass2::$pi;
    echo "<br>";
    $area = StaticClass2::getCircleArea(5);
    echo "원의 면적은 {$area}";
     ?>
  </body>
</html>
