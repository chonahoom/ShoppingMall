<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
    require_once '46instanceEx2.php';

    $a = new Member();
    $b = $a;//참조복사

    $a->id = 1001;
    $a->name = '김영진';
    var_dump($a==$b);
    print '<br>';
    var_dump($a===$b);
    print '<br>';

    $c = clone $a;
    var_dump($a==$c);
    print '<br>';
    var_dump($a===$c);
    print '<br>'; 
     ?>
  </body>
</html>
