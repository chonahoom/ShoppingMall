<?php
class SuperCls{
  public function disp(){
    print '제품명이 미등록입니다.';
  }
}
 ?>
