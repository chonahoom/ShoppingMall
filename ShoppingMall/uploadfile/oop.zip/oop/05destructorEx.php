<?php
class Destructor{
  public $num1;
  public $num2;
  public function __construct($a,$b){
    $this->num1 = $a;
    $this->num2 = $b;
  }
  //호출은 소멸될 때 자동 호출
  public function __destruct(){
    print "인스턴스 파기될 때 호출된거임.";
  }
}
 ?>
