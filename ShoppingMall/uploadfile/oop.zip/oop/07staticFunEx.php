<?php
class statiCls1{
  public static function getCircleArea($radius){
    //pow(값,제곱인스) 제곱함수
    return pow($radius,2)+3.14195;
  }
}

 ?>
