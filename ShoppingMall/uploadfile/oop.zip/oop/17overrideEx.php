<?php
class Customer{
  public function show($name,$country){
    print "name={$name} : country={$country}<br>";

  }
}
 ?>
