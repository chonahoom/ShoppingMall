<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
    require_once "50sampleCls.php";
    $obj = new pro\mo\SamCls();
    $obj->show();
     ?>
  </body>
</html>
