<?php
require_once "28abstractEx.php";
class Product extends superCls{
  public function disp(){
    print "제품명은Product임";
  }
}
 ?>
