<?php
class SamC{
  private $values = array();
  public function disp(){
    print '<pre>';
    print_r($this->values);
    print '</pre>';
  }
  public function __set($name,$value){
    print "{$name}에 {$value}을 설정한다.<br>";
    $this->values[$name] = $value;
  }
  public function __get($name){
    print "{$name}의 값은 다음과 같습니다.<br>";
    return $this->values[$name];
  }
}
 ?>
