<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
     require_once "18OverrideSubEx.php";
     $ob1 = new Customer();
     $ob1->show("이영진","대한민국");

     $ob2 = new CustomerSub();
     $ob2->show("이영진","대한민국");

     ?>
  </body>
</html>
