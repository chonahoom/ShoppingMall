<?php
class LSB_A{
  public function testAccess(){
    static::test();
  }
  public static function test(){
    print __CLASS__." : Hello PHP!<br>";
  }
}
 ?>
