<?php
class SamC2{
  private $values = array();
  
  public function disp(){
    print '<pre>';
    print_r($this->values);
    print '</pre>';
  }
  public function __set($name,$value){
    print "{$name}에 {$value}을 설정한다.<br>";
    $this->values[$name] = $value;
  }
  public function __get($name){
    if(!isset($this->value[$name])){
      print "{$name}의 값은 존재하지 않음.<br>";
    }else{
      print "{$name}의 값을 반환.<br>";
      return $this->values[$name];
    }
  }
  public function __isset($name){
    return isset($this->values[$name]);
  }
  public function __unset($name){
    unset($this->values[$name]);
  }
  public function test_0($val){
    return $this->values[$name]=$val;
  }
  public function test_1($val){
    return $this->values[$name]=$val;
  }
  public function __call($name,$param){//name 메소드의이름 , parma 파라미터의 갯수
    if(count($param)==0){
      if($name == 'test'){
        $this->test();
      }else if(count($param)==1){
        if($name=='test'){
          $this->test_1($param[0]);
        }
      }
      //return $this->values[$name];
    }else if(count($param)==1){
      $this->value[$name]=$param[0];
    }else{
      $this->values[$name]=$param[1];
    }
  }
}
 ?>
