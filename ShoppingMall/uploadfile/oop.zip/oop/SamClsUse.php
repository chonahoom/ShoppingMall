<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
    use proj\mod\SamCls as aa;
    require_once 'proj\mod\SamCls.php';
    $obj = new aa();
    $OBJ->show();
    // $obj = new proj\mod\SamCls();
    // $obj->show();
     ?>
  </body>
</html>
