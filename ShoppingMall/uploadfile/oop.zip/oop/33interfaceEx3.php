<?php
require_once "31interfaceEx1.php";
require_once "32interfaceEx2.php";
class SubC extends SuperC implements ISample{
  public function multi($n){
    //static fianl 이라서 접근가능
    if(ISample::NUM > $n){
      $this->val = $n*2;
    }else{
      $this->val = $n;
    }
  }
  public function dive($n){
    if(ISample::NUM < $n){
      $this->val = $n/2;
    }else{
      $this->val = $n;
    }
  }
}
 ?>
