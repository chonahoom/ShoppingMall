<?php
class Member{
  public $id;
  public $name;
}
 ?>
