<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
    require_once "05destructorEx.php";
    $obj = new Destructor(200,1.234);
    print("num1={$obj->num1}");
    print "<br>";
    print("num2={$obj->num2}");
    print "<br>";
     ?>
  </body>
</html>
