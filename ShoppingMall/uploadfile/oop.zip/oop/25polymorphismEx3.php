<?php
require_once "23polymorphismEx.php";
class Manufacture extends SuperCls{
  public function disp(){
    print "제품명은 Manufacture 입니다.";
  }
}
 ?>
