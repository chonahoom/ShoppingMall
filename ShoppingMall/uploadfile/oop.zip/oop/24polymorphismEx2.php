<?php
require_once "23polymorphismEx.php";
class Products extends SuperCls{
  public function disp(){
    print "제품명은 Proucts 입니다.";
  }
}
 ?>
