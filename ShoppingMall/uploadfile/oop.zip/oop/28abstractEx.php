<?php
abstract class superCls{
  abstract protected function disp();
}
 ?>
