<<<오-바-로-도>>>
1.일반적인정의
:메소드 처리를 상황에 따라 다른 처리로 변경하여 사용 가능 하도록 하는 것

php의 오-바-로-도 : 프로파티나 메소드를 동적으로 작성하여 사용하기 위한 방법
★Magic function : 이름,파라메-타,반환 호출의 타이밍만 결정되어 있음.
내용은 프로그래머가 결정(작성)하여 사용함
http://php.net/manual/kr/language.oop5.magic.php

__construct()
__destruct()
__call()
__callStatic()
__get()
__set()
__isset()
__unset()
__sleep()
__wakeup()
__toString()
__invoke()
__set_state()

1)오-바-로-도로 정의하지 않는 프로파티를 처리
__get() ==> 정의하지 않은 프로파티를 값을 불러올때
__set() ==> 정의하지 않은 프로파티에 값을 대입할때
__isset() ==> 정의하지 않은 프로파티를 isset함수로 호출
__unset() ==> 정의하지 않은 프로파티를 unset함수로 호출
2)오-바-로-도로 정의하지 않은 메소드를 처리
__call() ==> 정의하지 않은 메소드를 호출할 때
__callStatic() ==> 정의하지 않은 정적 메소드를 호출할 때

3)Late Static Bindings - 지연 정적 바인딩
※__CLASS__ : 현재의 클래스 명을 가지고 있는 상수

※프로파티,메소드를 지정
스코프(Scope)지정자       Scope         사용가능 장소
클래명::                지정한클래스     클래스밖,안
self::                self::가 작성된    클래스안
                      클래스
parent::              parent::가 작성된  클래스안
                      클래스의 부모클래스
static::              직근(直近)의 비전송
                      호출
