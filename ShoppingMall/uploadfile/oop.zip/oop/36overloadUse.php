<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
    require_once "35overloadEx1.php";
    $obj = new SamC();
    //SamC 에는 member ,id 라는 프로퍼티가 없다.
    $obj->member = "김영진";
    $obj->id = 1001;

    print $obj->member."<br>";
    print $obj->id."<br>";

    $obj->disp();
     ?>
  </body>
</html>
