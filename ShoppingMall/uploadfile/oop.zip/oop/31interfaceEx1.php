<?php
interface ISample{
  const NUM=100;
  public function multi($n);
  public function dive($n);
}
 ?>
