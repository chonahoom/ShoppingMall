<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
    //참조카운트에 관한것
    require_once "44instanceEx1.php";

    print '$a=new Test004()를 실행<br>';
    $a=new Test004();
    print '$b=$a를 실행<br>';
    $b=$a;
    print 'unset($a)를 를 실행 <br>';
    //unset($a);//참조카운터가내려간다
    print 'unset($a)를 를 실행 <br>';
    //unset($b);
    print 'testt<br>';
    print 'testt<br>';
    print 'testt<br>';
    print 'testt<br>';
    print 'testt<br>';
    print 'testt<br>';
    print 'testt<br>';
    print 'testt<br>';
    //프로그램이 끝나면 파기

    ?>
  </body>
</html>
