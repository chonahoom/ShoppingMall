<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
    require_once "46instanceEx2.php";
    $a = new Member();

    $a->id=1001;
    $a->name='김영진';

    $b = clone $a;//인스턴스 복사

    //$b = $a 참조복사

    $a->id = 1002;
    $a->name='이영진';

    print_r($a);
    echo "<br>";
    print_r($b);
     ?>
  </body>
</html>
