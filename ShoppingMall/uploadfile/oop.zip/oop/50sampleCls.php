<?php
namespace pro\mo;

class SamCls{
  public function show(){
    print '이름공간:['.__NAMESPACE__.']<br>';
  }
}
?>
