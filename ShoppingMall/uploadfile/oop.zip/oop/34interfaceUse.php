<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
    require_once "33interfaceEx3.php";
    $sc = new SubC();
    $sc->multi(50);
    $sc->show();

    $sc->dive(200);
    $sc->show(); 
     ?>
  </body>
</html>
