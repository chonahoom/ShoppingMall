<?php
class ConstCls{
  const PI=3.14;
  public static function getCircleArea($radius){
    return pow($radius,2)*self::PI;
  }
}
 ?>
