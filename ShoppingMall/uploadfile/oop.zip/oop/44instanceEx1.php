<?php
class Test004{
  public function __construct(){
    print __CLASS__ ."인스탄스가 생성되었습니다.<br>";
  }
  public function __destruct(){
    print __CLASS__.'인스탄스가 파기되었습니다.<br>';
  }
}
 ?>
