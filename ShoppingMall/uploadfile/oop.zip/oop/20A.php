<?php
class A{
  public $firstName;
  public function __construct($firstName){
    $this->firstName=$firstName;
    
  }
}
 ?>
