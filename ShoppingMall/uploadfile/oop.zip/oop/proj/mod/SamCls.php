<?php
namespace proj\mod;

class SamCls{
  public function show(){
    print '이름공간:['.__NAMESPACE__.']'.__CLASS__.'<br>';
  }
}
 ?>
