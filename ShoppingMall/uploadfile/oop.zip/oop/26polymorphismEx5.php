<?php
require_once "23polymorphismEx.php";
class Goods extends SuperCls{
  public function disp(){
    print "제품명은 Goods 입니다.";
  }
}
 ?>
