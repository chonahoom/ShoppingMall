<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
     require_once "11constEx.php";
     print "클래스 정수 PI =".ConstCls::PI;
     print "<br>";
     print "원의 면적:".ConstCls::getCircleArea(100);
     ?>
  </body>
</html>
