<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
    require_once "24polymorphismEx2.php";
    require_once "25polymorphismEx3.php";
    require_once "26polymorphismEx5.php";

    $obj1 = new Products();
    $obj1->disp();
    $obj2 = new Manufacture();
    $obj2->disp();
    $obj3 = new Goods();
    $obj3->disp();
     ?>
  </body>
</html>
