<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
    require_once "21B.php";
    $ob = new B('영진','김');
    $ob->show();
     ?>
  </body>
</html>
