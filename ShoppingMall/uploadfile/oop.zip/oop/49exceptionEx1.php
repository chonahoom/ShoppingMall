<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
    class MyZeroException extends Exception{
      public function getMsg(){
        return "오류코드: ".$this->getCode()."<br>오류메세지 :" .$this->getMessage();
      }
    }
    class MyNumFormatException extends Exception{
      public function getMsg(){
        return "오류코드: ".$this->getCode()."<br>오류메세지 :" .$this->getMessage();
      }
    }
    class Division{
      public static function divider($a,$b){
        //==0 ==> 숫자가 아니면 0으로 인지하는듯
        if($b===0){
          throw new MyZeroException('니 0으로 나눠 어짤라고?');
        }
        if(!is_numeric($a) || !is_numeric($b)){
          throw new MyNumFormatException('니 숫자 안넣고 계산할꺼임?');
        }
        return $a/$b;
      }
    }
    try{
      print Division::divider(1,'ad');
    }catch(MyZeroException $e){
      print $e->getMsg();
    }catch(MyNumFormatException $e){
      print $e->getMsg();
    }
     ?>
  </body>
</html>
