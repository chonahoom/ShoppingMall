<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
    require_once "37overloadEx2.php";
    $obj = new SamC2();
    $obj->member('김영진','최영진');
    echo $obj->member();

     ?>
  </body>
</html>
