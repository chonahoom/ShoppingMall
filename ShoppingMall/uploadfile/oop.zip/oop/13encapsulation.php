<?php
class CapsuleCls{
  const PI=3.14;
  private $radius;
  private $height;

  public function setRadius($r){
    $this->radius = $r;
  }
  public function setHeight($h){
    $this->height = $h;
  }
  public function getRadius(){
    return $this->radius;
  }
  public function getHeight(){
    return $this->height;
  }
  public function getVolume(){
    $area = pow($this->radius,2)*self::PI;
    return $area * $this->height/3;
  }
}
 ?>
