<<<예외처리:Exception>>>
try ~ catch
try{
  //예외가 발생될 것으로 예상되는 코드작성
}catch(예외클래스명 $변수명){
  //예외 발생시 실행해야 하는 코드 작성
}
프로그래머가 원하는 위치에서 예외를 발생
 throw new 발생시키고 싶은 예외클래스명();

사용자가정의 예외클래스 작성 : extends Exception
http://php.net/manual/en/class.exception.php

4)php5이전의 에러
set_error_handler()

<<<Namespace>>> java의 package와 유사
이름공간:이름충돌방지
1)정의
namespace 이름공간명;
※ 최선두에 공백이나 개행없이 정의해야한다.

2)사용
이름공간명\클래스명;
3)임포트
use 이름공간명\클래스명;

※이름공간 != 폴더
 권장==> 이름공간==폴더의 계층구조

※ 한파일에 두개의 이름공간사용가능?
{}을 이용,사용가능하다.==>권장안함
namespace 이름공간1{
  //소스코딩
}
namespace 이름공간2{
  //소스코딩
  
}

4)별명 - alias : 에이리마스(일본어)
use 이름공간명\클래스명 as 에이리아스명;
