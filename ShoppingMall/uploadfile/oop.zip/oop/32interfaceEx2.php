<?php
class SuperC{
  public $val;
  public function show(){
    print "val={$this->val}<br>";
  }
}
 ?>
