<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
      require_once "07staticFunEx.php";
      $area = statiCls1::getCircleArea(5);
      echo "원의 면적은 {$area}";
     ?>
  </body>
</html>
