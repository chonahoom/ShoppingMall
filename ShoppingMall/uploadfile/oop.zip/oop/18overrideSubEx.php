<?php
  require_once "17overrideEx.php";

  class CustomerSub extends Customer{
    public $nick='테스트';
    public function show($name,$country){
      //print "이름은{$name}이고 <br> 국적은 {$country}입니다.";
      parent::show($name,$country);
      print "니 별명은 {$this->nick}이다.<br>";
    }
  }
?>
