<?php
$a = 10;
$b = &$a;
$b = 40;
echo $a;
echo "<br>";
$a = 5;
echo $b;
 ?>
