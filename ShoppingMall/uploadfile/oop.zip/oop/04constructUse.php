<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
    require_once "03constructorEx.php";
    $price = new Calculate(0.08);
    echo "세금포함 가격은{$price->taxCalculate(1000)} 입니다.";
     ?>
  </body>
</html>
