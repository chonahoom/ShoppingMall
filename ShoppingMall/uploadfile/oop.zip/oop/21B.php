<?php
require_once "20A.php";
class B extends A{
  public $lastName;
  public function __construct($firstName,$lastName){
      parent::__construct($firstName);
      $this->lastName=$lastName;
  }
  public function show(){
    print "너의 이름은".$this->lastName . $this->firstName."이다<br>";
  }
}
 ?>
