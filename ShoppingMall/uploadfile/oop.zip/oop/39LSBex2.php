<?php
require_once "39LSBex1.php";

class LSB_B extends LSB_A{
  public static function test(){
    print __CLASS__." : Hello PHP!<br>";
  }
}
 ?>
