<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
      require_once "13encapsulation.php";
      $obj = new CapsuleCls;
      $obj->setRadius(10);
      $obj->setHeight(50);
      print "반지름:{$obj->getRadius()}"."<br>";
      print "높이:{$obj->getHeight()}"."<br>";
      print "채적:{$obj->getVolume()}"."<br>";
     ?>
  </body>
</html>
