<?php
class StaticClass2{
  public static $pi = 3.141592;
  public static function getCircleArea($radius){
    return pow($radius,2)*self::$pi;
  }
}
 ?>
