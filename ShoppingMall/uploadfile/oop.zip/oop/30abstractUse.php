<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
    require_once "29abstractEx2.php";
    $obj1 = new Product();
    $obj1->disp();
     ?>
  </body>
</html>
